"""Focused checks for historical data preparation."""

import hashlib
import math
import tempfile
import unittest
from pathlib import Path

import pandas as pd

from agent import ASSETS, PARTNERS, make_features, place_orders, predict_market
from clean_data import load_history
from train_model import build_examples


class HistoryLoadingTests(unittest.TestCase):
    def write_history(self, rows, directory):
        path = Path(directory) / "history.csv"
        pd.DataFrame(rows, columns=["round", "asset", "price"]).to_csv(path, index=False)
        return path

    def test_recovers_only_unique_missing_asset(self):
        with tempfile.TemporaryDirectory() as directory:
            rows = [(0, asset, 10.0) for asset in ASSETS[:-1]]
            rows.append((0, None, 42.0))
            path = self.write_history(rows, directory)

            prices, audit = load_history(path)

            self.assertEqual(prices.loc[0, ASSETS[-1]], 42.0)
            self.assertEqual(len(audit["recovered_labels"]), 1)
            self.assertEqual(audit["unresolved_rows"], [])

    def test_preserves_ambiguous_rows_without_attribution(self):
        with tempfile.TemporaryDirectory() as directory:
            rows = [(0, asset, 10.0) for asset in ASSETS[:-2]]
            rows.extend([(0, None, 41.0), (0, None, 42.0)])
            path = self.write_history(rows, directory)

            prices, audit = load_history(path)

            self.assertTrue(pd.isna(prices.loc[0, ASSETS[-2]]))
            self.assertTrue(pd.isna(prices.loc[0, ASSETS[-1]]))
            self.assertEqual(len(audit["unresolved_rows"]), 2)
            self.assertEqual({row["price"] for row in audit["unresolved_rows"]}, {41.0, 42.0})

    def test_preserves_missing_round_and_asset(self):
        with tempfile.TemporaryDirectory() as directory:
            rows = [(0, asset, 10.0) for asset in ASSETS]
            rows.extend((2, asset, 12.0) for asset in ASSETS[:-1])
            path = self.write_history(rows, directory)

            prices, audit = load_history(path)

            self.assertEqual(prices.index.tolist(), [0, 1, 2])
            self.assertTrue(prices.loc[1].isna().all())
            self.assertTrue(pd.isna(prices.loc[2, ASSETS[-1]]))
            self.assertEqual(audit["missing_observations"], 7)

    def test_does_not_modify_raw_input_or_fill_prices(self):
        with tempfile.TemporaryDirectory() as directory:
            rows = [(0, asset, 10.0) for asset in ASSETS]
            rows[0] = (0, ASSETS[0], None)
            path = self.write_history(rows, directory)
            before = hashlib.sha256(path.read_bytes()).hexdigest()

            prices, audit = load_history(path)

            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)
            self.assertTrue(pd.isna(prices.loc[0, ASSETS[0]]))
            self.assertEqual(audit["missing_prices"], 1)

    def test_rejects_duplicate_known_key(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self.write_history([(0, ASSETS[0], 10), (0, ASSETS[0], 11)], directory)

            with self.assertRaisesRegex(ValueError, "duplicate known round/asset keys"):
                load_history(path)

    def test_marks_nonfinite_and_invalid_prices_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = self.write_history(
                [(0, ASSETS[0], float("inf")), (0, ASSETS[1], "bad price")],
                directory,
            )

            prices, audit = load_history(path)

            self.assertTrue(prices.loc[0, [ASSETS[0], ASSETS[1]]].isna().all())
            self.assertEqual(audit["nonfinite_prices"], 1)
            self.assertEqual(audit["invalid_prices"], 1)


class ForecastTests(unittest.TestCase):
    def test_training_features_match_inference_and_ignore_target(self):
        prices = pd.DataFrame(
            {asset: [10.0, 11.0, 12.0, 13.0, 14.0] for asset in ASSETS}
        )
        asset = ASSETS[0]
        ratio_limits = {name: 2.1 for name in ASSETS}
        example = build_examples(prices, asset, 4, 5, ratio_limits)[0]
        history = {
            asset: prices[asset].iloc[:4].tolist(),
            PARTNERS[asset]: prices[PARTNERS[asset]].iloc[:4].tolist(),
        }
        reference, features, _ = make_features(history, asset, ratio_limits)
        self.assertEqual(example["reference"], reference)
        self.assertEqual(example["features"], features)

        prices.loc[4, asset] = 999.0
        changed_target = build_examples(prices, asset, 4, 5, ratio_limits)[0]
        self.assertEqual(changed_target["features"], features)

    def test_empty_short_and_missing_histories_produce_finite_prices(self):
        histories = [
            {},
            {asset: [42.0] for asset in ASSETS},
            {asset: [None, float("nan"), 30.0, float("inf")] for asset in ASSETS},
        ]
        for history in histories:
            with self.subTest(history=history):
                predictions = predict_market(history)
                self.assertEqual(set(predictions), set(ASSETS))
                self.assertTrue(all(math.isfinite(value) and value > 0 for value in predictions.values()))
                self.assertEqual(predictions, predict_market(history))

    def test_orders_use_native_integers_and_respect_budget(self):
        assets = {asset: {"recent_prices": [10.0, 11.0, 12.0]} for asset in ASSETS}
        state = {"trade_budget": 14, "assets": assets}
        orders = place_orders(state, [])
        self.assertEqual(set(orders), set(ASSETS))
        self.assertTrue(all(type(value) is int for value in orders.values()))
        self.assertLessEqual(sum(abs(value) for value in orders.values()), 14)

        for asset in ASSETS:
            assets[asset]["recent_prices"].append(None)
        self.assertEqual(place_orders(state, []), {asset: 0 for asset in ASSETS})


if __name__ == "__main__":
    unittest.main()
